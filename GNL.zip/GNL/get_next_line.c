/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   get_next_line.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rlahmaid <rlahmaid@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/10/25 23:17:06 by amoxe             #+#    #+#             */
/*   Updated: 2021/11/03 19:40:18 by rlahmaid         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "get_next_line.h"
#include <string.h>


int ft_strlen(char *str)    
{
    int i;

    i = 0;
    while (str[i])
        i++;
    return(i);
}

char    *ft_substr(char *str, int start, size_t len)
{
    int i;

    i = 0;
    char *new;
    
    if (!str)
        return (NULL);
    new = malloc(sizeof(char *) * (len + 1));
    if (!new)
        return (NULL);
    while (len)
    {
        new[i++] = str[start++];
        len--;
    }
    new[i] = '\0';
    return (new);
}
/////////////////////////////////////////////////////////////////////////


char    *look_for_backslash(char *buffer)
{
    int i;

    i = 0;
    if (!buffer)
        return (0);
    while (buffer[i])
    {
        if (buffer[i] == '\n')
            return(&buffer[i]);
        i++;
    }
    return(NULL);
}

char *join(char *tmp, char *buffer)
{
    int l1;
    int i;
    char *p;

    if (!tmp || !buffer)
        return (NULL);
    l1 = ft_strlen(tmp);
    i = 0;
    p = malloc(sizeof(char *) * (l1 + ft_strlen(buffer)));
    if (p == 0)
        return (NULL);
    while (tmp[i])
    {
        p[i] = tmp[i];
        i++;
    }
    i = 0;
    while (buffer[i])
    {
        p[i + l1] = buffer[i];
        i++;
    }
    p[i + l1] = '\0';
    return (p);
}

char    *tmp_to_line(char *tmp) //return line from tmp or tmp if there is no new line
{
    char *new;
    if (look_for_backslash(tmp) && ft_strlen(tmp) == ft_strlen(look_for_backslash(tmp)))
    {
        new = ft_substr(tmp, 0, ft_strlen(tmp) - ft_strlen(look_for_backslash(tmp)));
    }
    else if (look_for_backslash(tmp))
        new = ft_substr(tmp, 0, ft_strlen(tmp) - ft_strlen(look_for_backslash(tmp) + 1));
    else
        new = ft_substr(tmp, 0, ft_strlen(tmp));
    return (new);
}
/////////////////////////////////////////////////////////////////////////////////


char    *purge_line_from_tmp(char *tmp, char *line)
{
    char *new;

    if (!look_for_backslash(tmp))
    {
        free(tmp);
        return (NULL);
    }
    new = ft_substr(tmp, ft_strlen(line), ft_strlen(tmp) - ft_strlen(line) - 1);
    free(tmp);
    return (new);
}

char    *join_tmp(char *tmp, char *buffer)
{
    char *new;
    
    if (!tmp)
    {
        tmp = malloc(1);
        tmp[0] = '\0';
    }
    new = join(tmp, buffer);
    free(tmp);
    return (new);
}

 char    *read_from_file(int fd, char *tmp)
{
    char buffer[BUFFER_SIZE + 1];
    int ret;
    ret = 1;
  
     while (!look_for_backslash(tmp) && ret > 0)
     {
        ret = read(fd, buffer, BUFFER_SIZE);
        if ((ret == 0 && !tmp) || ret == -1)
        {
            free(tmp);
            return (NULL);
        }
        buffer[ret] = '\0';
        tmp = join_tmp(tmp, buffer);
     }
    return(tmp);
}

///////////////////////////////////////////////////////////////////////////////////

char    *get_next_line(int fd)
{
    static char *tmp;
    char *line;

    line = NULL;
    if (BUFFER_SIZE <= 0 || fd < 0)
        return(NULL);
    tmp = read_from_file(fd, tmp);
    if (tmp)
    {
        line = tmp_to_line(tmp);
        //printf("line : |%s|\n", line);
        tmp = purge_line_from_tmp(tmp, line);
        //free(tmp);
    }
    return (line);
}