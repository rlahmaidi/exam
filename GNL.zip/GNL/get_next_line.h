/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   header.h                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rlahmaid <rlahmaid@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/10/26 00:43:33 by amoxe             #+#    #+#             */
/*   Updated: 2021/11/03 17:24:36 by rlahmaid         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef HEADER_H
# define HEADER_H


#include <stdio.h>
#include<fcntl.h>
#include<unistd.h>
#include<stdlib.h>


char    *look_for_backslash(char *buffer);
char    *read_from_file(int fd, char *tmp);
char    *get_next_line(int fd);
char *str_dup(char *str);
int ft_strlen(char *str);

#endif