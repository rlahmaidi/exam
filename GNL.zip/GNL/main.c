/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rlahmaid <rlahmaid@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/10/25 23:13:15 by amoxe             #+#    #+#             */
/*   Updated: 2021/11/03 19:39:17 by rlahmaid         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "header.h"

int main(int argc, char **argv)
{
	int		fd;
	// int		ret;
	char	*line;
	fd = 0;
	// ret = 1;
	if (argc > 1)
		fd = open(argv[1], O_RDONLY);
	while ((line = get_next_line(fd)))
    {
		printf("%s\n",line);
        free(line);
    }
    free(line);
    // fd = 0;
    // free(get_next_line(fd));
    return (0);
}