#include "my_header.h"

char *ft_substr(char *str, int start, size_t size)
{
    int i;
    char *tmp;

    i = 0;
    if (!str)
     return(NULL);
    tmp = malloc(sizeof(char *) * (size +1));
    if(!tmp)
     return(NULL);
    while(size)
    {
        tmp[i++] = str[start++];
        size--;
    }
    tmp[i] = '\0';
    return(tmp);
}

// char    *purge_line_from_tmp(char *tmp)
// {
//     char *new;

//     if(!look_for_back_slash(tmp))
//     {
//         free(tmp);
//         return(NULL);
//     }
//     new = substr(tmp,ft_strlen(look_for_back_slash(tmp)), ft_strlen(tmp) - ft_strlen(look_for_back_slash(tmp)));
//     free(tmp);
//     return(new);
// }

char    *purge_line_from_tmp(char *tmp, char *line)
{
    char *new;

    if (!look_for_back_slash(tmp))
    {
        free(tmp);
        return (NULL);
    }
    new = ft_substr(tmp, ft_strlen(line), ft_strlen(tmp) - ft_strlen(line));
    free(tmp);
    return (new);
}

// char *tmp_to_line(char *tmp)
// {
//     char *line;

//     if(look_for_back_slash(tmp))
//         line = ft_substr(tmp,0,ft_strlen(tmp) - ft_strlen(look_for_back_slash(tmp)));
//     else
//     line = ft_substr(tmp, 0, ft_strlen(tmp));
//     return(line);
// }
char    *tmp_to_line(char *tmp) //return line from tmp or tmp if there is no new line
{
    char *new;

    if (look_for_back_slash(tmp))
        new = ft_substr(tmp, 0, ft_strlen(tmp) - ft_strlen(look_for_back_slash(tmp)) + 1);
    else
        new = ft_substr(tmp, 0, ft_strlen(tmp));
    return (new);
}

int ft_strlen(char *str)
{
    int i;

    i = 0;
    while(str[i])
    {
        i++;
    }
    return(i);
}

char    *look_for_back_slash(char *buffer)
{
    int i;

    if (!buffer)
        return(NULL);
    i = 0;
    while(buffer[i])
    {
        if(buffer[i] == '\n')
            return(&buffer[i]);
        i++;
    }
    return(NULL);
}

char *join(char *tmp, char *buffer)
{
    char *new;
    int i; 

    if (!tmp || !buffer)
        return(NULL);
    new = malloc(sizeof(char *) *(ft_strlen(tmp) + ft_strlen(buffer)));
    if (new == 0)
        return(NULL);
    i = 0;
    while(tmp[i])
    {
        new[i] = tmp[i];
        i++;
    }
    i = 0 ;
    while (buffer[i])
    {
        new[ft_strlen(tmp) + i] = buffer[i];
        i++;
    }
    new[ft_strlen(tmp) +i] = '\0';
    return(new);
}


char    *join_tmp(char *tmp, char *buffer)
{
    char *new;
    
    if (!tmp)
    {
        tmp = malloc(1);
        tmp[0] = '\0';
    }
    new = join(tmp, buffer);
    free(tmp);
    return (new);
}

char *read_from_line(int fd, char *tmp)
{
    char buffer[BUFFER_SIZE +1];
    int ret;

    ret = 1;
    while (ret > 0 && !look_for_back_slash(tmp))
    {
        ret = read(fd,buffer,BUFFER_SIZE);
        if((ret == 0 && !tmp) || ret == -1)
        {
            free(tmp);
            return(NULL);
        }
        buffer[ret] = '\0';
        tmp = join_tmp(tmp,buffer);
    }
    return(tmp);
}

char *get_next_line(int fd)
{
    static char *tmp;
    char *line;

    line = NULL;
    if (fd < 0 || BUFFER_SIZE <=0)
        return (NULL);
    tmp = read_from_line(fd, tmp);
    if (tmp)
    {
        line = tmp_to_line(tmp);
        //tmp = purge_line_from_tmp(tmp);
        tmp = purge_line_from_tmp(tmp,line);
    }    
    return(line);
}