#ifndef HEADER_H
#define HEADER_H

#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <stdlib.h>


//char    *purge_line_from_tmp(char *tmp);
char    *purge_line_from_tmp(char *tmp, char *line);
char *ft_substr(char *str, int start, size_t size);
char *tmp_to_line(char *tmp);
int ft_strlen(char *str);
char    *look_for_back_slash(char *buffer);
char *join(char *tmp, char *buffer);
char *join_tmp(char *tmp, char *buffer);
char *read_from_line(int fd, char *tmp);
char *get_next_line(int fd);


#endif

